var annotated =
[
    [ "JQ6500_Serial", "class_j_q6500___serial.html", "class_j_q6500___serial" ]
];